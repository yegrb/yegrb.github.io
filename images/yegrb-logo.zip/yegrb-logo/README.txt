Thanks for participating in the YEGrb t-shirt design contest.

Please use the files in this package to enhance your design, and consider using our official colours in your layout.

## Colours

Red
Hex: #960921
CMYK: 26, 100, 93, 25

Midnight Blue
Hex: #101429
CMYK: 89, 82, 52, 68

Tan
Hex: #EAE4C7
CMYK: 8, 7, 23, 0

## Submitting

Once you've completed your design, please submit it as a PNG to tshirts@yegrb.com, or reply to us with a link on Twitter at @yegrb.
